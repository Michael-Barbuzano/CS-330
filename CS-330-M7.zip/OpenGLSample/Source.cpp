﻿#include <iostream>
#include <cstdlib>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <cmath>
#include <vector>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

using namespace std;

#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

namespace
{
    const char* const WINDOW_TITLE = "Mug";
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;
    GLFWwindow* gWindow = nullptr;
    GLuint gProgramId;

    // Declare global variables for light source properties
    GLint lightPositionLoc;
    GLint lightColorLoc;
    GLint lightIntensityLoc;


    glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 5.0f);
    glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
    glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
    float cameraSpeed = 0.1f;

    float lastX = WINDOW_WIDTH / 2.0f;
    float lastY = WINDOW_HEIGHT / 2.0f;
    float yaw = -90.0f;
    float pitch = 0.0f;
    bool firstMouse = true;
    float sensitivity = 0.1f;
    bool isPerspective = true; // Flag to determine if perspective or orthographic projection is used


    struct GLMesh
    {
        GLuint vao;
        GLuint vbos[2];
        GLuint nIndices;
    };

    GLMesh gCupMesh;
    GLMesh gHandleMesh;
    GLMesh gPlaneMesh;
    GLMesh gBoardMesh;
    GLuint texture;
    GLuint graniteTexture;
}

const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position;
layout(location = 1) in vec4 color;
layout(location = 2) in vec2 texCoord; // Add texture coordinate attribute

out vec4 vertexColor;
out vec2 vertexTexCoord; // Pass texture coordinate to fragment shader

uniform mat4 cupModel;
uniform mat4 handleModel;
uniform mat4 view;
uniform mat4 projection;
uniform mat4 planeModel;

// New uniform variable for controlling the color of the cup model
uniform vec4 cupColor;

// New uniform variable for the directional light direction
uniform vec3 lightDirection;

void main()
{
    vec4 transformedPosition;

    if (gl_InstanceID == 0) {
        transformedPosition = cupModel * vec4(position, 1.0);
        vertexColor = cupColor; // Set the vertex color for the cup model
    }
    else if (gl_InstanceID == 1) {
        transformedPosition = handleModel * vec4(position, 1.0);
        vertexColor = vec4(1.0, 1.0, 1.0, 1.0); // Set the vertex color for the handle model to white
    }
    else {
        transformedPosition = planeModel * vec4(position, 1.0);
        vertexColor = vec4(1.0, 1.0, 1.0, 1.0); // Set the vertex color for the plane model to white
    }

    gl_Position = projection * view * transformedPosition;
    vertexTexCoord = texCoord; // Pass texture coordinates for all models
}
);


const GLchar* fragmentShaderSource = GLSL(440,
    in vec4 vertexColor;
in vec2 vertexTexCoord; // Input texture coordinates from the vertex shader

out vec4 fragmentColor;

uniform sampler2D cupTexSampler;
uniform sampler2D texSampler; // Texture sampler uniform

// New uniform variables for lighting
uniform vec3 lightDirection;
uniform vec3 lightColor;
uniform float lightIntensity;


void main()
{
    // Sample the texture using the texture coordinates
    vec4 texColor = texture(texSampler, vertexTexCoord);

    // Calculate the surface normal using the dFdx and dFdy functions
    vec3 dtdx = dFdx(vec3(vertexTexCoord, 0.0));
    vec3 dtdy = dFdy(vec3(vertexTexCoord, 0.0));
    vec3 normal = normalize(cross(dtdx, dtdy));

    // Calculate the dot product of the light direction and the surface normal
    float diffuseFactor = max(dot(normal, lightDirection), 0.0);

    // Apply the light color and intensity to the texture color
    vec3 finalColor = texColor.rgb * (vertexColor.rgb * (lightColor * lightIntensity) + diffuseFactor);

    // Set the final color as the fragment color
    fragmentColor = vec4(finalColor, texColor.a);
}
);

void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    if (yoffset > 0)
        cameraSpeed *= 1.1f; // Increase camera speed by 10%
    else if (yoffset < 0)
        cameraSpeed *= 0.9f; // Decrease camera speed by 10%
}
bool initShaders(GLuint& programId);
bool UInitialize(int argc, char* argv[], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void URender();
void UCreateBoardMesh(GLMesh& mesh, float width, float height, float thickness);
void UCreateCupMesh(GLMesh& mesh, float outerRadius, float innerRadius, float height, int numSegments);
void UCreateHandleMesh(GLMesh& mesh, float torusRadius, float tubeRadius, float angleRange, int numSegments);
void UCreatePlaneMesh(GLMesh& mesh, float width, float height);
void UDestroyMesh(GLMesh& mesh);
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void updateCameraVectors();
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;
    UCreateBoardMesh(gBoardMesh, 1.0f, 0.1f, 1.0f); // Adjust the width, height, and thickness as needed
    UCreatePlaneMesh(gPlaneMesh, 5.0f, 5.0f);
    UCreateCupMesh(gCupMesh, 0.5f, 0.45f, 1.0f, 300);
    UCreateHandleMesh(gHandleMesh, 0.2f, 0.05f, 3.14f, 2000);

    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    // Initialize shaders
    if (!initShaders(gProgramId))
        return EXIT_FAILURE;

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    glfwSetScrollCallback(gWindow, scroll_callback);
    glfwSetInputMode(gWindow, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    glfwSetCursorPosCallback(gWindow, mouse_callback);
    glfwSetKeyCallback(gWindow, key_callback); // Register the key_callback function

    // Get the uniform locations for the light properties
    lightPositionLoc = glGetUniformLocation(gProgramId, "lightPosition");
    lightColorLoc = glGetUniformLocation(gProgramId, "lightColor");
    lightIntensityLoc = glGetUniformLocation(gProgramId, "lightIntensity");

    // Set the light properties
    glm::vec3 lightPosition = glm::vec3(10.0f, 5.0f, 5.0f); // light position
    glm::vec3 lightColor = glm::vec3(1.0f, 1.0f, 1.0f); // light color (white)
    float lightIntensity = 0.5f; //light intensity

    glUseProgram(gProgramId);
    glUniform3fv(lightPositionLoc, 1, glm::value_ptr(lightPosition));
    glUniform3fv(lightColorLoc, 1, glm::value_ptr(lightColor));
    glUniform1f(lightIntensityLoc, lightIntensity);

    while (!glfwWindowShouldClose(gWindow))
    {
        UProcessInput(gWindow);
        URender();
        glfwPollEvents();
    }

    UDestroyMesh(gCupMesh);
    UDestroyMesh(gHandleMesh);
    UDestroyShaderProgram(gProgramId);

    glfwTerminate();
    return EXIT_SUCCESS;
}


bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    if (!glfwInit())
    {
        cout << "Failed to initialize GLFW" << endl;
        return false;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, nullptr, nullptr);
    if (*window == nullptr)
    {
        cout << "Failed to create GLFW window" << endl;
        glfwTerminate();
        return false;
    }

    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);

    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK)
    {
        cout << "Failed to initialize GLEW" << endl;
        return false;
    }

    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;



    // Load the "granite.jpg" texture image
    int width, height, nrChannels;
    unsigned char* data2 = stbi_load("granite.jpg", &width, &height, &nrChannels, 0);

    if (!data2)
    {
        std::cerr << "Failed to load granite.jpg" << std::endl;
        return false;
    }

    glGenTextures(1, &graniteTexture);
    glBindTexture(GL_TEXTURE_2D, graniteTexture);

    // Set the wrapping mode to GL_REPEAT
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    // Set the texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // Load the texture data
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data2);
    glGenerateMipmap(GL_TEXTURE_2D);

    // Load the texture image
    
    unsigned char* data = stbi_load("pattern.jpg", &width, &height, &nrChannels, 0);

    if (!data)
    {
        std::cerr << "Failed to load pattern.jpg" << std::endl;
        return false;
    }

    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);

    // Setting wrapping mode to GL_REPEAT
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    // Set the texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // Load texture data
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);

    stbi_image_free(data);



    return true;
}
bool initShaders(GLuint& programId)
{
    // Your shader source code goes here, same as before...
    // ...

    // Create and compile the vertex shader
    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderSource, nullptr);
    glCompileShader(vertexShader);

    // Check for vertex shader compilation errors...

    // Create and compile the fragment shader
    GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, nullptr);
    glCompileShader(fragmentShader);

    // Check for fragment shader compilation errors...

    // Create and link the shader program
    programId = glCreateProgram();
    glAttachShader(programId, vertexShader);
    glAttachShader(programId, fragmentShader);
    glLinkProgram(programId);

    // Check for shader program linking errors...

    // Clean up the individual shaders
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);

    return true;
}

void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

void UProcessInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraUp;
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraUp;
}

void URender()
{
    glEnable(GL_DEPTH_TEST);
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
    glm::mat4 projection = glm::perspective(glm::radians(45.0f), static_cast<float>(WINDOW_WIDTH) / WINDOW_HEIGHT, 0.1f, 100.0f);

    glUseProgram(gProgramId);

    GLint viewLoc = glGetUniformLocation(gProgramId, "view");
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));

    GLint projLoc = glGetUniformLocation(gProgramId, "projection");
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    if (isPerspective)
    {
        // Set up the perspective projection matrix
        int width, height;
        glfwGetFramebufferSize(gWindow, &width, &height);
        float aspectRatio = static_cast<float>(width) / static_cast<float>(height);
        glm::mat4 projection = glm::perspective(glm::radians(45.0f), aspectRatio, 0.1f, 100.0f);
        glUniformMatrix4fv(glGetUniformLocation(gProgramId, "projection"), 1, GL_FALSE, glm::value_ptr(projection));
    }
    else
    {
        // Set up the orthographic projection matrix
        int width, height;
        glfwGetFramebufferSize(gWindow, &width, &height);
        float aspectRatio = static_cast<float>(width) / static_cast<float>(height);
        float orthoScale = 1.0f; // You can adjust this scale according to your scene size
        glm::mat4 projection = glm::ortho(-orthoScale * aspectRatio, orthoScale * aspectRatio, -orthoScale, orthoScale, 0.1f, 100.0f);
        glUniformMatrix4fv(glGetUniformLocation(gProgramId, "projection"), 1, GL_FALSE, glm::value_ptr(projection));
    }

    // Bind the graniteTexture to texture unit 1
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, graniteTexture);
    // Set the uniform texSampler for graniteTexture to use texture unit 1
    glUniform1i(glGetUniformLocation(gProgramId, "texSampler"), 1);

    // Bind the pattern texture to texture unit 0
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texture);
    // Set the uniform texSampler for pattern texture to use texture unit 0
    glUniform1i(glGetUniformLocation(gProgramId, "cupTexSampler"), 0);

    // Draw the plane
    {
        // Apply the rotations to the plane model matrix
        glm::mat4 planeRotation = glm::rotate(glm::radians(-90.0f), glm::vec3(1.0f, 0.0f, 0.0f)); // Rotate around X-axis by -90 degrees

        // Apply translation to move the plane down
        glm::mat4 planeTranslation = glm::translate(glm::vec3(0.0f, -5.5f, 0.0f));

        // Combine the rotations into the plane model matrix
        glm::mat4 planeModel = planeTranslation * planeRotation;

        GLint planeModelLoc = glGetUniformLocation(gProgramId, "planeModel");
        glUniformMatrix4fv(planeModelLoc, 1, GL_FALSE, glm::value_ptr(planeModel));


        glBindVertexArray(gPlaneMesh.vao);
        glDrawElements(GL_TRIANGLES, gPlaneMesh.nIndices, GL_UNSIGNED_INT, nullptr);
        glBindVertexArray(0);
    }
    


    // Draw the cup model
    {
        glm::mat4 cupScale = glm::scale(glm::vec3(2.0f, 2.0f, 2.0f));
        glm::mat4 cupRotation = glm::rotate(50.0f, glm::vec3(1.0f, 1.0f, 1.0f));
        glm::mat4 cupTranslation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
        glm::mat4 cupModel = cupTranslation * cupRotation * cupScale;

        GLint cupModelLoc = glGetUniformLocation(gProgramId, "cupModel");
        glUniformMatrix4fv(cupModelLoc, 1, GL_FALSE, glm::value_ptr(cupModel));

        // Set the cup color to white (1.0, 1.0, 1.0, 1.0) before rendering the cup model
        GLint cupColorLoc = glGetUniformLocation(gProgramId, "cupColor");
        glUniform4f(cupColorLoc, 1.0f, 1.0f, 1.0f, 1.0f);
        
        glUniform1i(glGetUniformLocation(gProgramId, "texSampler"), 0);

        glBindVertexArray(gCupMesh.vao);
        glDrawElements(GL_TRIANGLES, gCupMesh.nIndices, GL_UNSIGNED_INT, nullptr);
        glBindVertexArray(0);
    }

    // Draw the handle model
    {
        glm::mat4 handleScale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
        glm::mat4 handleRotation = glm::rotate(50.0f, glm::vec3(1.0f, 1.0f, 1.0f));
        glm::mat4 handleTranslation = glm::translate(glm::vec3(3.0f, 0.0f, 0.0f));
        glm::mat4 handleModel = handleTranslation * handleRotation * handleScale;

        GLint handleModelLoc = glGetUniformLocation(gProgramId, "handleModel");
        glUniformMatrix4fv(handleModelLoc, 1, GL_FALSE, glm::value_ptr(handleModel));

        glUniform1i(glGetUniformLocation(gProgramId, "texSampler"), 0);

        glBindVertexArray(gHandleMesh.vao);
        glDrawElements(GL_TRIANGLES, gHandleMesh.nIndices, GL_UNSIGNED_INT, nullptr);
        glBindVertexArray(0);
    }
    {
        // Apply transformations to the cutting board model matrix
        glm::mat4 boardScale = glm::scale(glm::vec3(0.1f, 0.1f, 0.1f)); // Adjust the scale
        glm::mat4 boardTranslation = glm::translate(glm::vec3(0.0f, -5.6f, 0.0f)); // Adjust the translation
        glm::mat4 boardModel = boardTranslation * boardScale;

        GLint boardModelLoc = glGetUniformLocation(gProgramId, "boardModel");
        glUniformMatrix4fv(boardModelLoc, 1, GL_FALSE, glm::value_ptr(boardModel));

        glBindVertexArray(gBoardMesh.vao);
        glDrawElements(GL_TRIANGLES, gBoardMesh.nIndices, GL_UNSIGNED_INT, nullptr);
        glBindVertexArray(0);
    }

    glfwSwapBuffers(gWindow);
}




void UCreateCupMesh(GLMesh& mesh, float outerRadius, float innerRadius, float height, int numSegments)
{
    std::vector<GLfloat> verts;
    std::vector<GLuint> indices;

    float angleStep = (2.0f * 3.14159265359f) / numSegments;
    float halfHeight = height / 2.0f;


    // Translate the cup along the x-axis
    glm::mat4 translationMatrix = glm::translate(glm::vec3(30.0f, 0.0f, 0.0f));


    for (int i = 0; i <= numSegments; i++)
    {

        


        float angle = i * angleStep;
        float xOuter = outerRadius * cos(angle);
        float zOuter = outerRadius * sin(angle);
        float xInner = innerRadius * cos(angle);
        float zInner = innerRadius * sin(angle);

        glm::vec4 vertexPositionOuterTop = translationMatrix * glm::vec4(xOuter, halfHeight, zOuter, 1.0f);
        glm::vec4 vertexPositionOuterBottom = translationMatrix * glm::vec4(xOuter, -halfHeight, zOuter, 1.0f);
        glm::vec4 vertexPositionInnerTop = translationMatrix * glm::vec4(xInner, halfHeight, zInner, 1.0f);
        glm::vec4 vertexPositionInnerBottom = translationMatrix * glm::vec4(xInner, -halfHeight, zInner, 1.0f);

        // Outer top vertex
        verts.push_back(xOuter);
        verts.push_back(halfHeight);
        verts.push_back(zOuter);
        // Outer normal
        verts.push_back(xOuter);
        verts.push_back(0.0f);
        verts.push_back(zOuter);
        // Texture coordinates
        verts.push_back(1.0f - static_cast<float>(i) / numSegments);
        verts.push_back(0.0f);

        // Outer bottom vertex
        verts.push_back(xOuter);
        verts.push_back(-halfHeight);
        verts.push_back(zOuter);
        // Outer normal
        verts.push_back(xOuter);
        verts.push_back(0.0f);
        verts.push_back(zOuter);
        // Texture coordinates
        verts.push_back(1.0f - static_cast<float>(i) / numSegments);
        verts.push_back(1.0f);

        // Inner top vertex
        verts.push_back(xInner);
        verts.push_back(halfHeight);
        verts.push_back(zInner);
        // Inner normal
        verts.push_back(xInner);
        verts.push_back(0.0f);
        verts.push_back(zInner);
        // Texture coordinates
        verts.push_back(1.0f - static_cast<float>(i) / numSegments);
        verts.push_back(0.0f);

        // Inner bottom vertex
        verts.push_back(xInner);
        verts.push_back(-halfHeight);
        verts.push_back(zInner);
        // Inner normal
        verts.push_back(xInner);
        verts.push_back(0.0f);
        verts.push_back(zInner);
        // Texture coordinates
        verts.push_back(1.0f - static_cast<float>(i) / numSegments);
        verts.push_back(1.0f);
    }

    for (int i = 0; i < numSegments; i++)
    {
        // Indices for the rectangles
        int baseIndex = i * 4;
        indices.push_back(baseIndex);
        indices.push_back(baseIndex + 1);
        indices.push_back(baseIndex + 2);
        indices.push_back(baseIndex + 1);
        indices.push_back(baseIndex + 3);
        indices.push_back(baseIndex + 2);
    }

    mesh.nIndices = indices.size();

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);

    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, verts.size() * sizeof(GLfloat), verts.data(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(GLuint), indices.data(), GL_STATIC_DRAW);

    GLint stride = 8 * sizeof(GLfloat); // Position (3 floats) + Normal (3 floats) + Texture coordinates (2 floats)

    // Vertex position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, nullptr);
    glEnableVertexAttribArray(0);

    // Vertex normal attribute
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(GLfloat)));
    glEnableVertexAttribArray(1);

    // Texture coordinates attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(GLfloat)));
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}




void UCreateHandleMesh(GLMesh& mesh, float torusRadius, float tubeRadius, float angleRange, int numSegments)
{
    vector<GLfloat> verts;
    vector<GLuint> indices;

    float angleStep = angleRange / numSegments;
    float halfTubeRadius = tubeRadius / 2.0f;

    for (int i = 0; i <= numSegments; i++)
    {
        float angle = i * angleStep;
        float xOuter = (torusRadius + halfTubeRadius) * cos(angle);
        float yOuter = (torusRadius + halfTubeRadius) * sin(angle);
        float xInner = (torusRadius - halfTubeRadius) * cos(angle);
        float yInner = (torusRadius - halfTubeRadius) * sin(angle);

        // Outer top vertex
        verts.push_back(-yOuter * 1.5f + 0.6f);
        verts.push_back(xOuter * 1.5f);
        verts.push_back(0.0f);
        verts.push_back(1.0f);
        verts.push_back(0.0f);
        verts.push_back(0.0f);
        verts.push_back(1.0f);

        // Outer bottom vertex
        verts.push_back(-yOuter * 1.5f + 0.6f);
        verts.push_back(xOuter * 1.5f);
        verts.push_back(-tubeRadius);
        verts.push_back(1.0f);
        verts.push_back(1.0f);
        verts.push_back(0.0f);
        verts.push_back(1.0f);

        // Inner top vertex
        verts.push_back(-yInner * 1.5f + 0.6f);
        verts.push_back(xInner * 1.5f);
        verts.push_back(0.0f);
        verts.push_back(1.0f);
        verts.push_back(1.0f);
        verts.push_back(0.0f);
        verts.push_back(1.0f);

        // Inner bottom vertex
        verts.push_back(-yInner * 1.5f + 0.6f);
        verts.push_back(xInner * 1.5f);
        verts.push_back(-tubeRadius);
        verts.push_back(1.0f);
        verts.push_back(0.0f);
        verts.push_back(0.0f);
        verts.push_back(1.0f);

        int baseIndex = i * 4;

        indices.push_back(baseIndex);
        indices.push_back(baseIndex + 1);
        indices.push_back(baseIndex + 2);
        indices.push_back(baseIndex + 2);
        indices.push_back(baseIndex + 1);
        indices.push_back(baseIndex + 3);

        if (i < numSegments)
        {
            indices.push_back(baseIndex + 2);
            indices.push_back(baseIndex + 3);
            indices.push_back(baseIndex + 6);
            indices.push_back(baseIndex + 3);
            indices.push_back(baseIndex + 7);
            indices.push_back(baseIndex + 6);
        }
    }
    // Translate the handle along the x-axis
    glm::mat4 translationMatrix = glm::translate(glm::vec3(-1.1f, 0.0f, 0.0f));

    // Rotate the handle vertically
    glm::mat4 rotationMatrix = glm::rotate(glm::radians(-180.0f), glm::vec3(0.0f, 0.0f, 1.0f));
    mesh.nIndices = indices.size();

    for (int i = 0; i < verts.size(); i += 7)
    {
        glm::vec4 vertexPosition(verts[i], verts[i + 1], verts[i + 2], 1.0f);

        // Apply translation
        vertexPosition = translationMatrix * vertexPosition;

        // Apply rotation
        vertexPosition = rotationMatrix * vertexPosition;

        // Update the vertex position
        verts[i] = vertexPosition.x;
        verts[i + 1] = vertexPosition.y;
        verts[i + 2] = vertexPosition.z;
    }

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);

    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, verts.size() * sizeof(GLfloat), verts.data(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(GLuint), indices.data(), GL_STATIC_DRAW);

    GLint stride = 7 * sizeof(GLfloat);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, nullptr);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(GLfloat)));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, stride, (void*)(7 * sizeof(GLfloat)));
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, stride, (void*)((7 * sizeof(GLfloat)) + (3 * sizeof(GLfloat))));
    glEnableVertexAttribArray(3);
}
void UCreatePlaneMesh(GLMesh& mesh, float width, float height)
{
    vector<GLfloat> verts;
    vector<GLuint> indices;

    float halfWidth = width / 2.0f;
    float halfHeight = height / 2.0f;
    float lowerAmount = -0.5f; // Adjusting this value to lower the plane
    float scale = 2.0f;

    // Translate the plane along the x-axis (same translation as handle)
    glm::mat4 translationMatrix = glm::translate(glm::vec3(-3.1f, 0.0f, -3.0f));

    // Loop through vertices and apply translation
    for (int i = 0; i < 4; i++)
    {
        glm::vec4 vertexPosition;

        if (i == 0) // Bottom left corner
            vertexPosition = translationMatrix * glm::vec4(-halfWidth * scale, lowerAmount, -halfHeight * scale, 1.0f);
        else if (i == 1) // Bottom right corner
            vertexPosition = translationMatrix * glm::vec4(halfWidth * scale, lowerAmount, -halfHeight * scale, 1.0f);
        else if (i == 2) // Top right corner
            vertexPosition = translationMatrix * glm::vec4(halfWidth * scale, lowerAmount, halfHeight * scale, 1.0f);
        else if (i == 3) // Top left corner
            vertexPosition = translationMatrix * glm::vec4(-halfWidth * scale, lowerAmount, halfHeight * scale, 1.0f);

        // Vertex position
        verts.push_back(vertexPosition.x);
        verts.push_back(vertexPosition.y);
        verts.push_back(vertexPosition.z);


    }

    // Indices
    indices.push_back(0);
    indices.push_back(1);
    indices.push_back(2);
    indices.push_back(2);
    indices.push_back(3);
    indices.push_back(0);

    mesh.nIndices = indices.size();

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);

    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, verts.size() * sizeof(GLfloat), verts.data(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(GLuint), indices.data(), GL_STATIC_DRAW);

    GLint stride = 3 * sizeof(GLfloat); // Position (3 floats)

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, nullptr); // Position attribute
    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}
void UCreateBoardMesh(GLMesh& mesh, float width, float height, float thickness)
{
    vector<GLfloat> verts;
    vector<GLuint> indices;

    float halfWidth = width / 2.0f;
    float halfHeight = height / 2.0f;
    float halfThickness = thickness / 2.0f;

    // Vertex positions
    glm::vec3 vertices[8] = {
        {-halfWidth, -halfHeight, -halfThickness},
        {halfWidth, -halfHeight, -halfThickness},
        {halfWidth, halfHeight, -halfThickness},
        {-halfWidth, halfHeight, -halfThickness},
        {-halfWidth, -halfHeight, halfThickness},
        {halfWidth, -halfHeight, halfThickness},
        {halfWidth, halfHeight, halfThickness},
        {-halfWidth, halfHeight, halfThickness}
    };

    // Indices for front and back faces
    GLuint frontIndices[] = { 0, 1, 2, 2, 3, 0 };
    GLuint backIndices[] = { 5, 4, 7, 7, 6, 5 };

    // Indices for side faces
    GLuint sideIndices[] = {
        0, 4, 7, 7, 3, 0, // Left side
        1, 5, 6, 6, 2, 1, // Right side
        3, 2, 6, 6, 7, 3, // Top side
        1, 0, 4, 4, 5, 1  // Bottom side
    };

    // Combine all indices
    indices.insert(indices.end(), std::begin(frontIndices), std::end(frontIndices));
    indices.insert(indices.end(), std::begin(backIndices), std::end(backIndices));
    indices.insert(indices.end(), std::begin(sideIndices), std::end(sideIndices));

    // Fill the vertex data array
    for (int i = 0; i < 8; i++)
    {
        verts.push_back(vertices[i].x);
        verts.push_back(vertices[i].y);
        verts.push_back(vertices[i].z);
        verts.push_back(0.0f); // U coordinate of the texture (you can adjust this)
        verts.push_back(0.0f); // V coordinate of the texture (you can adjust this)
        verts.push_back(1.0f); // Red component of the color
        verts.push_back(1.0f); // Green component of the color
        verts.push_back(1.0f); // Blue component of the color
    }

    mesh.nIndices = indices.size();

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);

    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, verts.size() * sizeof(GLfloat), verts.data(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(GLuint), indices.data(), GL_STATIC_DRAW);

    GLint stride = 8 * sizeof(GLfloat);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, nullptr);                          // Position attribute
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(GLfloat)));    // Texture coordinates
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, stride, (void*)(5 * sizeof(GLfloat)));    // Color attribute
    glEnableVertexAttribArray(2);
}











void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);
}

bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    GLint success;
    GLchar infoLog[512];

    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vtxShaderSource, nullptr);
    glCompileShader(vertexShader);

    glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShader, 512, nullptr, infoLog);
        cout << "ERROR: Vertex shader compilation failed\n" << infoLog << endl;
        return false;
    }

    GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragShaderSource, nullptr);
    glCompileShader(fragmentShader);

    glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShader, 512, nullptr, infoLog);
        cout << "ERROR: Fragment shader compilation failed\n" << infoLog << endl;
        return false;
    }

    programId = glCreateProgram();
    glAttachShader(programId, vertexShader);
    glAttachShader(programId, fragmentShader);
    glLinkProgram(programId);

    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, 512, nullptr, infoLog);
        cout << "ERROR: Shader program linking failed\n" << infoLog << endl;
        return false;
    }

    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);

    // Get the uniform locations for light properties
    lightPositionLoc = glGetUniformLocation(programId, "lightPosition");
    lightColorLoc = glGetUniformLocation(programId, "lightColor");
    lightIntensityLoc = glGetUniformLocation(programId, "lightIntensity");


    return true;
}

void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}

void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xOffset = xpos - lastX;
    float yOffset = lastY - ypos;

    lastX = xpos;
    lastY = ypos;

    xOffset *= sensitivity;
    yOffset *= sensitivity;

    yaw += xOffset;
    pitch += yOffset;


    if (pitch > 89.0f)
        pitch = 89.0f;
    if (pitch < -89.0f)
        pitch = -89.0f;

    updateCameraVectors();
}

void updateCameraVectors()
{
    glm::vec3 front;
    front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    front.y = sin(glm::radians(pitch));
    front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(front);
}
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    // Check if the 'P' key is pressed and toggle the perspective mode
    if (key == GLFW_KEY_P && action == GLFW_PRESS)
    {
        isPerspective = !isPerspective;
        if (isPerspective)
        {
            // When switching to perspective, set up the perspective projection matrix
            int width, height;
            glfwGetFramebufferSize(window, &width, &height);
            float aspectRatio = static_cast<float>(width) / static_cast<float>(height);
            glm::mat4 projection = glm::perspective(glm::radians(45.0f), aspectRatio, 0.1f, 100.0f);
            glUseProgram(gProgramId);
            glUniformMatrix4fv(glGetUniformLocation(gProgramId, "projection"), 1, GL_FALSE, glm::value_ptr(projection));
        }
        else
        {
            // Set up the orthographic projection matrix
            int width, height;
            glfwGetFramebufferSize(gWindow, &width, &height);
            float aspectRatio = static_cast<float>(width) / static_cast<float>(height);
            float orthoScale = 1.0f;
            glm::mat4 projection = glm::ortho(-orthoScale * aspectRatio, orthoScale * aspectRatio, -orthoScale, orthoScale, 0.1f, 100.0f);
            glUniformMatrix4fv(glGetUniformLocation(gProgramId, "projection"), 1, GL_FALSE, glm::value_ptr(projection));
        }
    }
}

